package com.authservice.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.authservice.service.JwtService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class UserController {

    private static final Logger logger = LoggerFactory.getLogger(UserController.class);
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private final JwtService jwtService;

    public UserController(JwtService jwtService) {
        this.jwtService = jwtService;
    }

    @PostMapping("/ldap-login")
    public Map<String, Object> login(Authentication authentication) {
        String username = authentication.getName();
        String timestamp = LocalDateTime.now().format(formatter);
        logger.info("[{}] LDAP LOGIN: User '{}' is requesting an access token.", timestamp, username);

        String token = jwtService.generateToken(authentication);
        var authorities = authentication.getAuthorities().stream()
                .map(grantedAuthority -> grantedAuthority.getAuthority())
                .toList();

        return Map.of(
                "access_token", token,
                "authorities", authorities,
                "username", authentication.getName());
    }

    @GetMapping("/resource/user")
    @PreAuthorize("hasRole('USER') or hasAuthority('SCOPE_read')")
    public Map<String, String> userResource() {
        String timestamp = LocalDateTime.now().format(formatter);
        logger.info("[{}] RESOURCE ACCESS: Accessing /resource/user", timestamp);
        return Map.of("message", "Accessible by USER role or read scope");
    }

    @GetMapping("/resource/admin")
    @PreAuthorize("hasRole('ADMIN')")
    public Map<String, String> adminResource() {
        String timestamp = LocalDateTime.now().format(formatter);
        logger.info("[{}] RESOURCE ACCESS: Accessing /resource/admin", timestamp);
        return Map.of("message", "Accessible by ADMIN role only");
    }
}
