package com.authservice;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.io.File;

@SpringBootApplication
public class AuthServiceApplication {

    private static final Logger logger = LoggerFactory.getLogger(AuthServiceApplication.class);

    public static void main(String[] args) {
        logger.info("Main: Starting AuthServiceApplication...");
        SpringApplication.run(AuthServiceApplication.class, args);
        logger.info("Main: AuthServiceApplication started successfully.");
    }

    @Bean
    public CommandLineRunner diagnosticRunner(@Value("${app.static-resources-path}") String path) {
        return args -> {
            logger.info("DIAGNOSTIC: Checking static resources path: {}", path);
            File folder = new File(path);
            if (folder.exists() && folder.isDirectory()) {
                logger.info("DIAGNOSTIC: Folder exists. Files found: ");
                File[] files = folder.listFiles();
                if (files != null) {
                    for (File f : files) {
                        logger.info("DIAGNOSTIC: - {}", f.getName());
                    }
                }
            } else {
                logger.error("DIAGNOSTIC: Folder DOES NOT EXIST or is not a directory: {}", path);
            }
        };
    }
}
