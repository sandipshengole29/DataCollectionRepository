package com.authservice.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.ldap.DefaultSpringSecurityContextSource;
import org.springframework.security.ldap.authentication.BindAuthenticator;
import org.springframework.security.ldap.authentication.LdapAuthenticationProvider;
import org.springframework.security.ldap.search.FilterBasedLdapUserSearch;
import org.springframework.security.ldap.userdetails.DefaultLdapAuthoritiesPopulator;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.oauth2.server.resource.authentication.JwtGrantedAuthoritiesConverter;
import org.springframework.security.web.SecurityFilterChain;

import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {

        private static final Logger logger = LoggerFactory.getLogger(SecurityConfig.class);

        @Value("${spring.ldap.urls}")
        private String ldapUrls;

        @Value("${spring.ldap.base}")
        private String ldapBase;

        @Value("${spring.ldap.user-search-base}")
        private String userSearchBase;

        @Value("${spring.ldap.user-search-filter}")
        private String userSearchFilter;

        @Value("${spring.ldap.group-search-base}")
        private String groupSearchBase;

        @Value("${spring.ldap.group-role-attribute}")
        private String groupRoleAttribute;

        @Value("${spring.ldap.group-search-filter}")
        private String groupSearchFilter;

        @Value("${jwt.secret}")
        private String jwtSecret;

        @Value("${app.security.login-page}")
        private String loginPage;

        @Value("${app.security.login-processing-url}")
        private String loginProcessingUrl;

        @Value("${app.security.default-success-url}")
        private String defaultSuccessUrl;

        @Value("${app.security.logout-success-url}")
        private String logoutSuccessUrl;

        @Bean
        @Order(1)
        public SecurityFilterChain ldapFilterChain(HttpSecurity http) throws Exception {
                logger.info("SecurityConfig: Configuring ldapFilterChain for /api/ldap-login/**");
                http
                                .securityMatcher("/api/ldap-login/**")
                                .csrf(AbstractHttpConfigurer::disable)
                                .authorizeHttpRequests(auth -> auth.anyRequest().authenticated())
                                .httpBasic(Customizer.withDefaults())
                                .authenticationProvider(ldapAuthenticationProvider());

                return http.build();
        }

        @Bean
        @Order(2)
        public SecurityFilterChain resourceServerFilterChain(HttpSecurity http) throws Exception {
                logger.info("SecurityConfig: Configuring resourceServerFilterChain for /api/**");
                http
                                .securityMatcher("/api/**")
                                .authorizeHttpRequests(auth -> auth
                                                .requestMatchers("/", loginPage, "/favicon.ico", "/css/**",
                                                                "/images/**", "/error**", "/api/ldap-login/**")
                                                .permitAll()
                                                .anyRequest().authenticated())
                                .oauth2ResourceServer(oauth2 -> oauth2
                                                .jwt(jwt -> jwt.jwtAuthenticationConverter(
                                                                jwtAuthenticationConverter())));

                return http.build();
        }

        @Bean
        public JwtAuthenticationConverter jwtAuthenticationConverter() {
                JwtGrantedAuthoritiesConverter grantedAuthoritiesConverter = new JwtGrantedAuthoritiesConverter();
                grantedAuthoritiesConverter.setAuthoritiesClaimName("roles");
                grantedAuthoritiesConverter.setAuthorityPrefix("ROLE_");

                JwtAuthenticationConverter jwtAuthenticationConverter = new JwtAuthenticationConverter();
                jwtAuthenticationConverter.setJwtGrantedAuthoritiesConverter(grantedAuthoritiesConverter);
                return jwtAuthenticationConverter;
        }

        @Bean
        @Order(3)
        public SecurityFilterChain defaultFilterChain(HttpSecurity http) throws Exception {
                logger.info("SecurityConfig: Configuring defaultFilterChain");
                http
                                .csrf(AbstractHttpConfigurer::disable)
                                .authorizeHttpRequests(auth -> auth
                                                .requestMatchers("/", loginPage, "/favicon.ico", "/css/**",
                                                                "/images/**", "/error**", "/api/ldap-login/**")
                                                .permitAll()
                                                .anyRequest().authenticated())
                                .formLogin(form -> form
                                                .loginPage(loginPage)
                                                .loginProcessingUrl(loginProcessingUrl)
                                                .defaultSuccessUrl(defaultSuccessUrl, true)
                                                .permitAll())
                                .logout(logout -> logout
                                                .logoutSuccessUrl(logoutSuccessUrl)
                                                .permitAll());

                return http.build();
        }

        @Bean
        public JwtDecoder jwtDecoder() {
                byte[] decodedKey = Base64.getDecoder().decode(jwtSecret);
                SecretKeySpec secretKey = new SecretKeySpec(decodedKey, 0, decodedKey.length, "HmacSHA256");
                return NimbusJwtDecoder.withSecretKey(secretKey).build();
        }

        @Bean
        public DefaultSpringSecurityContextSource contextSource() {
                return new DefaultSpringSecurityContextSource(ldapUrls + "/" + ldapBase);
        }

        @Bean
        public LdapAuthenticationProvider ldapAuthenticationProvider() {
                FilterBasedLdapUserSearch userSearch = new FilterBasedLdapUserSearch(
                                userSearchBase, userSearchFilter, contextSource());

                BindAuthenticator authenticator = new BindAuthenticator(contextSource());
                authenticator.setUserSearch(userSearch);

                DefaultLdapAuthoritiesPopulator authoritiesPopulator = new DefaultLdapAuthoritiesPopulator(
                                contextSource(), groupSearchBase);
                authoritiesPopulator.setGroupRoleAttribute(groupRoleAttribute);
                authoritiesPopulator.setGroupSearchFilter(groupSearchFilter);

                return new LdapAuthenticationProvider(authenticator, authoritiesPopulator);
        }
}
