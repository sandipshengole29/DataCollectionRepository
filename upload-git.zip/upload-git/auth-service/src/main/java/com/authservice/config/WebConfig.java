package com.authservice.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.lang.NonNull;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    private static final Logger logger = LoggerFactory.getLogger(WebConfig.class);

    @Value("${app.static-resources-path}")
    private String staticResourcesPath;

    @Override
    public void addResourceHandlers(@NonNull ResourceHandlerRegistry registry) {
        String path = staticResourcesPath.endsWith("/") ? staticResourcesPath : staticResourcesPath + "/";
        String location = "file:" + path;

        logger.info("WebConfig: Configuring Resource Handler '/**' mapping to '{}'", location);

        registry.addResourceHandler("/**")
                .addResourceLocations(location, "classpath:/static/", "classpath:/public/")
                .setCachePeriod(0);
    }

    @Override
    public void addViewControllers(@NonNull ViewControllerRegistry registry) {
        logger.info("WebConfig: Adding view controller for / to redirect to /login.html");
        registry.addViewController("/").setViewName("redirect:/login.html");
    }
}
