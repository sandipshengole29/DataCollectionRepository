package com.example.authservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthServiceOauth2Application {

    public static void main(String[] args) {
        SpringApplication.run(AuthServiceOauth2Application.class, args);
    }

}
