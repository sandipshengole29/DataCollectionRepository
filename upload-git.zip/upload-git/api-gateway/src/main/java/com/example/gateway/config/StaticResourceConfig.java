package com.example.gateway.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.config.ResourceHandlerRegistry;
import org.springframework.web.reactive.config.WebFluxConfigurer;
import org.springframework.lang.NonNull;

@Configuration
public class StaticResourceConfig implements WebFluxConfigurer {

    @Value("${app.static-resources-path}")
    private String staticResourcesPath;

    @Override
    public void addResourceHandlers(@NonNull ResourceHandlerRegistry registry) {
        String location = staticResourcesPath.endsWith("/") ? staticResourcesPath : staticResourcesPath + "/";
        registry.addResourceHandler("/**")
                .addResourceLocations(location)
                .addResourceLocations("classpath:/static/", "classpath:/public/")
                .setCacheControl(org.springframework.http.CacheControl.noCache());
    }
}
