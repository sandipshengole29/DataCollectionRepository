package com.example.gateway.controller;

import java.net.URI;

import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import reactor.core.publisher.Mono;

@Controller
public class WelcomeController {

//    @GetMapping("/")
//    public Mono<String> index() {
//        // Using redirect to ensure the browser explicitly requests /index.html
//        return Mono.just("forward:/index.html");
//    }
	
	@GetMapping("/")
	public Mono<Void> redirect(ServerHttpResponse response) {
	    response.setStatusCode(HttpStatus.FOUND);
	    response.getHeaders().setLocation(URI.create("/index.html"));
	    return response.setComplete();
	}

}
