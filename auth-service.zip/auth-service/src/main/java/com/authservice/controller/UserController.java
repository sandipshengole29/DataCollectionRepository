package com.authservice.controller;

import com.authservice.service.JwtService;
import java.util.Objects;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClient;

import java.util.Map;

@RestController
@RequestMapping("/api")
public class UserController {

    private final JwtService jwtService;
    private final RestClient restClient;

    @Value("${external.github-api-url}")
    private String githubApiUrl;

    public UserController(JwtService jwtService, RestClient.Builder restClientBuilder) {
        this.jwtService = jwtService;
        this.restClient = restClientBuilder.build();
    }

    @PostMapping("/ldap-login")
    public Map<String, String> login(Authentication authentication) {
        String token = jwtService.generateToken(authentication);
        return Map.of("token", token);
    }

    @GetMapping("/resource/user")
    @PreAuthorize("hasRole('USER') or hasAuthority('SCOPE_read')")
    public Map<String, String> userResource() {
        return Map.of("message", "Accessible by USER role or read scope");
    }

    @GetMapping("/resource/admin")
    @PreAuthorize("hasRole('ADMIN')")
    public Map<String, String> adminResource() {
        return Map.of("message", "Accessible by ADMIN role only");
    }

    @GetMapping("/external-call")
    public String callExternalApi() {
        // Demonstrate RestClient usage
        // Note: In a real scenario, you'd pass the OAuth2 token here
        return restClient.get()
                .uri(Objects.requireNonNull(githubApiUrl))
                .header("Accept", "application/vnd.github+json")
                .retrieve()
                .body(String.class);
    }
}
