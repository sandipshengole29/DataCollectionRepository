LDAP Login:
curl -u admin:adminpassword -X POST http://localhost:8082/api/ldap-login

Access Secured Resource: Take the token from the login step and use it in the Authorization header:
curl -H "Authorization: Bearer <your_token>" http://localhost:8082/api/resource/admin

OAuth2 Login: Access http://localhost:8082/login in a browser to see the GitHub login option (requires valid GITHUB_CLIENT_ID in environment/config).


Start the auth-service.
Navigate to http://localhost:8082/login.html (or just http://localhost:8082/ which will redirect you there).
Log in using your LDAP credentials.
You will be automatically redirected to the new Dashboard.
