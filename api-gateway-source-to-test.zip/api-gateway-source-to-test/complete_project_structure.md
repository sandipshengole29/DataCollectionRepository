# Spring Cloud API Gateway - Complete Project Structure

## Directory Structure
```
api-gateway/
├── pom.xml
├── src/main/java/com/example/apigateway/
│   ├── ApiGatewayApplication.java
│   ├── config/
│   │   ├── GatewayConfig.java
│   │   └── SecurityConfig.java
│   ├── controller/
│   │   └── HealthController.java
│   ├── filter/
│   │   └── AuthenticationFilter.java
│   ├── service/
│   │   └── LdapTokenValidationService.java
│   └── util/
│       └── JwtUtil.java
├── src/main/resources/
│   └── application.yml
├── docker-compose.yml
└── README.md
```

## File Contents

### pom.xml
```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>
    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>3.2.0</version>
        <relativePath/>
    </parent>
    <groupId>com.example</groupId>
    <artifactId>api-gateway</artifactId>
    <version>0.0.1-SNAPSHOT</version>
    <name>api-gateway</name>
    <description>Spring Cloud API Gateway with JWT Authentication</description>
    <properties>
        <java.version>17</java.version>
        <spring-cloud.version>2023.0.0</spring-cloud.version>
    </properties>
    <dependencies>
        <!-- Spring Cloud Gateway -->
        <dependency>
            <groupId>org.springframework.cloud</groupId>
            <artifactId>spring-cloud-starter-gateway</artifactId>
        </dependency>
        
        <!-- Eureka Client -->
        <dependency>
            <groupId>org.springframework.cloud</groupId>
            <artifactId>spring-cloud-starter-netflix-eureka-client</artifactId>
        </dependency>
        
        <!-- Load Balancer -->
        <dependency>
            <groupId>org.springframework.cloud</groupId>
            <artifactId>spring-cloud-starter-loadbalancer</artifactId>
        </dependency>
        
        <!-- Spring Security for JWT -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-security</artifactId>
        </dependency>
        
        <!-- JWT -->
        <dependency>
            <groupId>io.jsonwebtoken</groupId>
            <artifactId>jjwt-api</artifactId>
            <version>0.11.5</version>
        </dependency>
        <dependency>
            <groupId>io.jsonwebtoken</groupId>
            <artifactId>jjwt-impl</artifactId>
            <version>0.11.5</version>
            <scope>runtime</scope>
        </dependency>
        <dependency>
            <groupId>io.jsonwebtoken</groupId>
            <artifactId>jjwt-jackson</artifactId>
            <version>0.11.5</version>
            <scope>runtime</scope>
        </dependency>
        
        <!-- Spring Boot Actuator -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-actuator</artifactId>
        </dependency>
        
        <!-- Reactive Web -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-webflux</artifactId>
        </dependency>
        
        <!-- Configuration Processor -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-configuration-processor</artifactId>
            <optional>true</optional>
        </dependency>
        
        <!-- Test Dependencies -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>
    </dependencies>
    
    <dependencyManagement>
        <dependencies>
            <dependency>
                <groupId>org.springframework.cloud</groupId>
                <artifactId>spring-cloud-dependencies</artifactId>
                <version>${spring-cloud.version}</version>
                <type>pom</type>
                <scope>import</scope>
            </dependency>
        </dependencies>
    </dependencyManagement>
    
    <build>
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
            </plugin>
        </plugins>
    </build>
</project>
```

### src/main/resources/application.yml
```yaml
server:
  port: 8080

spring:
  application:
    name: api-gateway
  cloud:
    gateway:
      discovery:
        locator:
          enabled: true
          lower-case-service-id: true
      routes:
        - id: user-service
          uri: lb://user-service
          predicates:
            - Path=/api/users/**
          filters:
            - StripPrefix=2
            - name: AuthenticationFilter
        - id: order-service
          uri: lb://order-service
          predicates:
            - Path=/api/orders/**
          filters:
            - StripPrefix=2
            - name: AuthenticationFilter
        - id: product-service
          uri: lb://product-service
          predicates:
            - Path=/api/products/**
          filters:
            - StripPrefix=2
            - name: AuthenticationFilter
      default-filters:
        - DedupeResponseHeader=Access-Control-Allow-Credentials Access-Control-Allow-Origin
      globalcors:
        corsConfigurations:
          '[/**]':
            allowedOrigins: "*"
            allowedMethods: "*"
            allowedHeaders: "*"

eureka:
  client:
    service-url:
      defaultZone: http://localhost:8761/eureka/
    fetch-registry: true
    register-with-eureka: true
  instance:
    hostname: localhost
    prefer-ip-address: true

# JWT Configuration
jwt:
  secret: ${JWT_SECRET:mySecretKey}
  expiration: ${JWT_EXPIRATION:86400000}
  header: Authorization
  prefix: "Bearer "

# LDAP Authorization Server Configuration
ldap:
  auth-server:
    token-validation-url: ${LDAP_TOKEN_VALIDATION_URL:http://localhost:8083/auth/validate}
    timeout: 5000

# Logging
logging:
  level:
    org.springframework.cloud.gateway: DEBUG
    org.springframework.security: DEBUG
    com.example: DEBUG

# Management endpoints
management:
  endpoints:
    web:
      exposure:
        include: health,info,gateway
  endpoint:
    health:
      show-details: always
```

### src/main/java/com/example/apigateway/ApiGatewayApplication.java
```java
package com.example.apigateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class ApiGatewayApplication {

    public static void main(String[] args) {
        SpringApplication.run(ApiGatewayApplication.class, args);
    }
}
```

### src/main/java/com/example/apigateway/util/JwtUtil.java
```java
package com.example.apigateway.util;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.function.Function;

@Component
public class JwtUtil {

    @Value("${jwt.secret}")
    private String secret;

    @Value("${jwt.expiration}")
    private Long expiration;

    private SecretKey getSigningKey() {
        byte[] keyBytes = secret.getBytes(StandardCharsets.UTF_8);
        return Keys.hmacShaKeyFor(keyBytes);
    }

    public String extractUsername(String token) {
        return extractClaim(token, Claims::getSubject);
    }

    public Date extractExpiration(String token) {
        return extractClaim(token, Claims::getExpiration);
    }

    public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = extractAllClaims(token);
        return claimsResolver.apply(claims);
    }

    private Claims extractAllClaims(String token) {
        return Jwts.parserBuilder()
                .setSigningKey(getSigningKey())
                .build()
                .parseClaimsJws(token)
                .getBody();
    }

    public Boolean isTokenExpired(String token) {
        return extractExpiration(token).before(new Date());
    }

    public Boolean validateToken(String token, String username) {
        final String extractedUsername = extractUsername(token);
        return (extractedUsername.equals(username) && !isTokenExpired(token));
    }

    public Boolean isValidToken(String token) {
        try {
            Claims claims = extractAllClaims(token);
            return !isTokenExpired(token);
        } catch (Exception e) {
            return false;
        }
    }

    public String extractRole(String token) {
        Claims claims = extractAllClaims(token);
        return claims.get("role", String.class);
    }

    public String extractAuthorities(String token) {
        Claims claims = extractAllClaims(token);
        return claims.get("authorities", String.class);
    }
}
```

### src/main/java/com/example/apigateway/service/LdapTokenValidationService.java
```java
package com.example.apigateway.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.time.Duration;

@Service
public class LdapTokenValidationService {

    private static final Logger logger = LoggerFactory.getLogger(LdapTokenValidationService.class);

    private final WebClient webClient;

    @Value("${ldap.auth-server.token-validation-url}")
    private String tokenValidationUrl;

    @Value("${ldap.auth-server.timeout}")
    private int timeout;

    public LdapTokenValidationService(WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder.build();
    }

    public Mono<Boolean> validateToken(String token) {
        logger.debug("Validating token with LDAP authorization server");

        return webClient.post()
                .uri(tokenValidationUrl)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .header(HttpHeaders.AUTHORIZATION, "Bearer " + token)
                .bodyValue(new TokenValidationRequest(token))
                .retrieve()
                .onStatus(HttpStatus::is4xxClientError, response -> {
                    logger.warn("Token validation failed with status: {}", response.statusCode());
                    return Mono.just(new RuntimeException("Invalid token"));
                })
                .onStatus(HttpStatus::is5xxServerError, response -> {
                    logger.error("LDAP server error with status: {}", response.statusCode());
                    return Mono.just(new RuntimeException("LDAP server error"));
                })
                .bodyToMono(TokenValidationResponse.class)
                .map(TokenValidationResponse::isValid)
                .timeout(Duration.ofMillis(timeout))
                .doOnSuccess(isValid -> logger.debug("Token validation result: {}", isValid))
                .doOnError(error -> logger.error("Error validating token: {}", error.getMessage()))
                .onErrorReturn(false); // Return false if any error occurs
    }

    // DTO classes for request/response
    public static class TokenValidationRequest {
        private String token;

        public TokenValidationRequest() {}

        public TokenValidationRequest(String token) {
            this.token = token;
        }

        public String getToken() {
            return token;
        }

        public void setToken(String token) {
            this.token = token;
        }
    }

    public static class TokenValidationResponse {
        private boolean valid;
        private String username;
        private String[] roles;
        private long expiresAt;

        public TokenValidationResponse() {}

        public boolean isValid() {
            return valid;
        }

        public void setValid(boolean valid) {
            this.valid = valid;
        }

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String[] getRoles() {
            return roles;
        }

        public void setRoles(String[] roles) {
            this.roles = roles;
        }

        public long getExpiresAt() {
            return expiresAt;
        }

        public void setExpiresAt(long expiresAt) {
            this.expiresAt = expiresAt;
        }
    }
}
```

### src/main/java/com/example/apigateway/filter/AuthenticationFilter.java
```java
package com.example.apigateway.filter;

import com.example.apigateway.service.LdapTokenValidationService;
import com.example.apigateway.util.JwtUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

@Component
public class AuthenticationFilter extends AbstractGatewayFilterFactory<AuthenticationFilter.Config> {

    private static final Logger logger = LoggerFactory.getLogger(AuthenticationFilter.class);

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private LdapTokenValidationService ldapTokenValidationService;

    @Value("${jwt.header}")
    private String headerName;

    @Value("${jwt.prefix}")
    private String tokenPrefix;

    public AuthenticationFilter() {
        super(Config.class);
    }

    @Override
    public GatewayFilter apply(Config config) {
        return (exchange, chain) -> {
            ServerHttpRequest request = exchange.getRequest();
            
            // Check if Authorization header is present
            if (!request.getHeaders().containsKey(HttpHeaders.AUTHORIZATION)) {
                return onError(exchange, "Missing Authorization header", HttpStatus.UNAUTHORIZED);
            }

            String authHeader = request.getHeaders().getFirst(HttpHeaders.AUTHORIZATION);
            
            if (authHeader == null || !authHeader.startsWith(tokenPrefix)) {
                return onError(exchange, "Invalid Authorization header format", HttpStatus.UNAUTHORIZED);
            }

            String token = authHeader.substring(tokenPrefix.length());

            // Validate token with LDAP authorization server
            return ldapTokenValidationService.validateToken(token)
                    .flatMap(isValid -> {
                        if (isValid) {
                            try {
                                // Additional JWT validation if needed
                                if (jwtUtil.isValidToken(token)) {
                                    String username = jwtUtil.extractUsername(token);
                                    String role = jwtUtil.extractRole(token);
                                    
                                    // Add user information to request headers for downstream services
                                    ServerHttpRequest modifiedRequest = request.mutate()
                                            .header("X-User-Id", username)
                                            .header("X-User-Role", role != null ? role : "USER")
                                            .build();
                                    
                                    logger.info("Authentication successful for user: {}", username);
                                    return chain.filter(exchange.mutate().request(modifiedRequest).build());
                                } else {
                                    return onError(exchange, "Invalid JWT token", HttpStatus.UNAUTHORIZED);
                                }
                            } catch (Exception e) {
                                logger.error("Error validating JWT token: {}", e.getMessage());
                                return onError(exchange, "Token validation error", HttpStatus.UNAUTHORIZED);
                            }
                        } else {
                            return onError(exchange, "Token validation failed with LDAP server", HttpStatus.UNAUTHORIZED);
                        }
                    })
                    .onErrorResume(throwable -> {
                        logger.error("Error during token validation: {}", throwable.getMessage());
                        return onError(exchange, "Authentication service unavailable", HttpStatus.SERVICE_UNAVAILABLE);
                    });
        };
    }

    private Mono<Void> onError(ServerWebExchange exchange, String error, HttpStatus httpStatus) {
        logger.error("Authentication error: {}", error);
        ServerHttpResponse response = exchange.getResponse();
        response.setStatusCode(httpStatus);
        response.getHeaders().add("Content-Type", "application/json");
        
        String errorResponse = String.format("{\"error\": \"%s\", \"status\": %d}", error, httpStatus.value());
        return response.writeWith(Mono.just(response.bufferFactory().wrap(errorResponse.getBytes())));
    }

    public static class Config {
        // Configuration properties if needed
    }
}
```

### src/main/java/com/example/apigateway/config/SecurityConfig.java
```java
package com.example.apigateway.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.web.server.SecurityWebFilterChain;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.reactive.CorsConfigurationSource;
import org.springframework.web.cors.reactive.UrlBasedCorsConfigurationSource;

import java.util.Arrays;
import java.util.List;

@Configuration
@EnableWebFluxSecurity
public class SecurityConfig {

    @Bean
    public SecurityWebFilterChain securityWebFilterChain(ServerHttpSecurity http) {
        return http
                .csrf().disable()
                .cors().configurationSource(corsConfigurationSource())
                .and()
                .authorizeExchange(exchanges -> exchanges
                        .pathMatchers("/actuator/**").permitAll()
                        .pathMatchers("/eureka/**").permitAll()
                        .anyExchange().permitAll() // Gateway handles authentication via filters
                )
                .build();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedOriginPatterns(List.of("*"));
        configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        configuration.setAllowedHeaders(Arrays.asList("*"));
        configuration.setAllowCredentials(true);
        configuration.setMaxAge(3600L);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }
}
```

### src/main/java/com/example/apigateway/config/GatewayConfig.java
```java
package com.example.apigateway.config;

import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class GatewayConfig {

    @Bean
    @LoadBalanced
    public WebClient.Builder webClientBuilder() {
        return WebClient.builder();
    }

    @Bean
    public RouteLocator customRouteLocator(RouteLocatorBuilder builder) {
        return builder.routes()
                // Health check route (no authentication required)
                .route("health-check", r -> r
                        .path("/health")
                        .uri("http://localhost:8080/actuator/health"))
                
                // Gateway routes (authentication required)
                .route("user-service-route", r -> r
                        .path("/api/users/**")
                        .filters(f -> f
                                .stripPrefix(2)
                                .filter(new com.example.apigateway.filter.AuthenticationFilter().apply(
                                        new com.example.apigateway.filter.AuthenticationFilter.Config()))
                        )
                        .uri("lb://user-service"))
                
                .route("order-service-route", r -> r
                        .path("/api/orders/**")
                        .filters(f -> f
                                .stripPrefix(2)
                                .filter(new com.example.apigateway.filter.AuthenticationFilter().apply(
                                        new com.example.apigateway.filter.AuthenticationFilter.Config()))
                        )
                        .uri("lb://order-service"))
                
                .route("product-service-route", r -> r
                        .path("/api/products/**")
                        .filters(f -> f
                                .stripPrefix(2)
                                .filter(new com.example.apigateway.filter.AuthenticationFilter().apply(
                                        new com.example.apigateway.filter.AuthenticationFilter.Config()))
                        )
                        .uri("lb://product-service"))
                
                .build();
    }
}
```

### src/main/java/com/example/apigateway/controller/HealthController.java
```java
package com.example.apigateway.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@RestController
public class HealthController {

    @GetMapping("/health")
    public Mono<Map<String, Object>> health() {
        Map<String, Object> response = new HashMap<>();
        response.put("status", "UP");
        response.put("service", "api-gateway");
        response.put("timestamp", LocalDateTime.now());
        response.put("message", "API Gateway is running successfully");
        return Mono.just(response);
    }

    @GetMapping("/info")
    public Mono<Map<String, Object>> info() {
        Map<String, Object> response = new HashMap<>();
        response.put("service", "api-gateway");
        response.put("version", "1.0.0");
        response.put("description", "Spring Cloud API Gateway with JWT Authentication and Load Balancing");
        response.put("features", new String[]{
                "JWT Token Validation",
                "LDAP Integration",
                "Load Balancing",
                "Service Discovery",
                "Route Management"
        });
        return Mono.just(response);
    }
}
```

### docker-compose.yml
```yaml
version: '3.8'

services:
  eureka-server:
    image: steeltoeoss/eureka-server:3.1.1
    container_name: eureka-server
    ports:
      - "8761:8761"
    environment:
      - EUREKA_CLIENT_REGISTER_WITH_EUREKA=false
      - EUREKA_CLIENT_FETCH_REGISTRY=false
    networks:
      - microservice-network

  api-gateway:
    build: .
    container_name: api-gateway
    ports:
      - "8080:8080"
    environment:
      - SPRING_PROFILES_ACTIVE=docker
      - EUREKA_CLIENT_SERVICE_URL_DEFAULTZONE=http://eureka-server:8761/eureka/
      - JWT_SECRET=myVerySecureJWTSecretKeyForProduction
      - LDAP_TOKEN_VALIDATION_URL=http://ldap-auth-server:8083/auth/validate
    depends_on:
      - eureka-server
    networks:
      - microservice-network

  # Mock LDAP Authorization Server for testing
  ldap-auth-server:
    image: wiremock/wiremock:latest
    container_name: ldap-auth-server
    ports:
      - "8083:8080"
    volumes:
      - ./wiremock:/home/wiremock
    command: ["--global-response-templating", "--verbose"]
    networks:
      - microservice-network

  # Sample microservice for testing
  user-service:
    image: nginx:alpine
    container_name: user-service
    ports:
      - "8081:80"
    volumes:
      - ./nginx-config/user-service.conf:/etc/nginx/conf.d/default.conf
    networks:
      - microservice-network

  order-service:
    image: nginx:alpine
    container_name: order-service
    ports:
      - "8082:80"
    volumes:
      - ./nginx-config/order-service.conf:/etc/nginx/conf.d/default.conf
    networks:
      - microservice-network

networks:
  microservice-network:
    driver: bridge
```

## Setup Instructions

1. **Create the project directory structure as shown above**
2. **Copy each file content to its respective location**
3. **Run the following commands:**

```bash
# Create directory structure
mkdir -p api-gateway/src/main/java/com/example/apigateway/{config,controller,filter,service,util}
mkdir -p api-gateway/src/main/resources

# Navigate to project directory
cd api-gateway

# Build the project
mvn clean install

# Run the application
mvn spring-boot:run
```

## Quick Setup Script

```bash
#!/bin/bash

# Create project structure
mkdir -p api-gateway/src/main/java/com/example/apigateway/{config,controller,filter,service,util}
mkdir -p api-gateway/src/main/resources
cd api-gateway

# Copy all the file contents from above into their respective files
# Then run:
mvn clean install
mvn spring-boot:run
```

This complete project structure contains all the files you need for the Spring Cloud API Gateway with JWT authentication, LDAP integration, load balancing, and Eureka service discovery.